package com.chess.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

public class OverlayService extends Service {
    private MediaProjection proj;
    private VirtualDisplay vd;
    private ImageReader reader;
    private WindowManager wm;
    private ArrowView overlay;
    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private boolean running = false;
    private boolean busy = false;
    private int[] lastClean = null;
    private long lastCleanTime = 0;
    private float bx, by, bs;
    private int capW, capH;
    private int arrowFromScr = -1, arrowToScr = -1;

    private final Runnable tickR = new Runnable() {
        @Override
        public void run() {
            tick();
        }
    };

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || running) return START_NOT_STICKY;
        Crash.install(this);
        startFg();
        try {
            int code = intent.getIntExtra("code", 0);
            Intent data = intent.getParcelableExtra("data");
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            proj = mpm.getMediaProjection(code, data);
            proj.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            stopSelf();
                        }
                    });
                }
            }, ui);

            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int w = dm.widthPixels, h = dm.heightPixels;
            capW = w;
            capH = h;
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3);
            vd = proj.createVirtualDisplay("chess", w, h, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

            addOverlay();
            addWeb();
            running = true;
            ui.postDelayed(tickR, 1500);
        } catch (Throwable e) {
            Crash.save(this, "start: " + e);
            Toast.makeText(this, "Ошибка запуска: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startFg() {
        String ch = "chess_overlay";
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(ch, "Шахматный оверлей", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, ch)
                .setContentTitle("Шахматный оверлей работает")
                .setContentText("Открой Chess.com — стрелка покажет ход")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    private void addOverlay() {
        overlay = new ArrowView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(overlay, lp);
    }

    private void addWeb() throws Exception {
        web = new WebView(getApplicationContext());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadDataWithBaseURL("https://chess.local/", readAsset("core.html"), "text/html", "utf-8", null);
        WindowManager.LayoutParams wl = new WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        wl.gravity = Gravity.TOP | Gravity.START;
        wm.addView(web, wl);
    }

    private String readAsset(String name) throws Exception {
        InputStream in = getAssets().open(name);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int k;
        while ((k = in.read(buf)) > 0) bo.write(buf, 0, k);
        in.close();
        return bo.toString("UTF-8");
    }

    private class Bridge {
        @JavascriptInterface
        public void result(final String json) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    handle(json);
                }
            });
        }
    }

    private void handle(String json) {
        try {
            JSONObject o = new JSONObject(json);
            overlay.setInfo(o.optString("text", ""));
            int from = o.optInt("from", -1), to = o.optInt("to", -1);
            if (from >= 0 && to >= 0 && bs > 0) {
                boolean white = "w".equals(o.optString("bottom", "w"));
                int sf = white ? from : 63 - from;
                int st = white ? to : 63 - to;
                float sq = bs / 8f;
                overlay.setArrow(bx + (sf % 8 + 0.5f) * sq, by + (sf / 8 + 0.5f) * sq,
                        bx + (st % 8 + 0.5f) * sq, by + (st / 8 + 0.5f) * sq, sq);
                arrowFromScr = sf;
                arrowToScr = st;
            } else {
                overlay.clearArrow();
            }
        } catch (Throwable e) {
            // ignore
        }
    }

    /* ---------- цикл съёмки ---------- */

    private void tick() {
        if (!running) return;
        ui.postDelayed(tickR, 700);
        if (busy) return;
        ensureSize();
        Image im;
        try {
            im = reader.acquireLatestImage();
        } catch (Throwable e) {
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (im == null) {
            if (overlay.isShowing() && now - lastCleanTime > 5000) forceClean();
            return;
        }
        decodeAsync(im, new Consumer<Detector.Board>() {
            @Override
            public void accept(Detector.Board b) {
                if (b == null) {
                    if (overlay.isShowing()) overlay.clearArrow();
                    overlay.setInfo(Detector.lastBlack ? "Чёрный кадр: при запуске выбери «Весь экран»" : "");
                    return;
                }
                if (!overlay.isShowing()) {
                    acceptClean(b);
                    return;
                }
                if (changedOutsideArrow(b) || SystemClock.uptimeMillis() - lastCleanTime > 5000) {
                    forceClean();
                }
            }
        });
    }


    /* поворот экрана / смена размера: пересоздаём приёмник кадров */
    private void ensureSize() {
        try {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            if (dm.widthPixels == capW && dm.heightPixels == capH) return;
            ImageReader nr = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 3);
            vd.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi);
            vd.setSurface(nr.getSurface());
            ImageReader old = reader;
            reader = nr;
            if (old != null) old.close();
            capW = dm.widthPixels;
            capH = dm.heightPixels;
            lastClean = null;
            overlay.clearArrow();
        } catch (Throwable e) {
            // ignore
        }
    }

    private void forceClean() {
        if (busy) return;
        busy = true;
        overlay.setHidden(true);
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                busy = false;
                Image i2 = null;
                try {
                    i2 = reader.acquireLatestImage();
                } catch (Throwable e) {
                    // ignore
                }
                if (i2 == null) {
                    overlay.setHidden(false);
                    return;
                }
                decodeAsync(i2, new Consumer<Detector.Board>() {
                    @Override
                    public void accept(Detector.Board b) {
                        if (b == null) {
                            overlay.clearArrow();
                            overlay.setInfo("");
                            return;
                        }
                        acceptClean(b);
                    }
                });
            }
        }, 350);
    }

    private void acceptClean(Detector.Board b) {
        lastClean = b.obs.clone();
        lastCleanTime = SystemClock.uptimeMillis();
        bx = b.x0;
        by = b.y0;
        bs = b.s;
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < 64; i++) {
            if (i > 0) sb.append(',');
            sb.append(b.obs[i]);
        }
        sb.append(']');
        web.evaluateJavascript("window.onObs('" + sb + "')", null);
    }

    private boolean changedOutsideArrow(Detector.Board b) {
        if (lastClean == null) return true;
        int[] o = b.obs.clone();
        float sq = b.s / 8f;
        if (arrowFromScr >= 0 && arrowToScr >= 0) {
            float ax = b.x0 + (arrowFromScr % 8 + 0.5f) * sq, ay = b.y0 + (arrowFromScr / 8 + 0.5f) * sq;
            float cx = b.x0 + (arrowToScr % 8 + 0.5f) * sq, cy = b.y0 + (arrowToScr / 8 + 0.5f) * sq;
            float dx = cx - ax, dy = cy - ay;
            float len2 = dx * dx + dy * dy;
            for (int i = 0; i < 64; i++) {
                float px = b.x0 + (i % 8 + 0.5f) * sq, py = b.y0 + (i / 8 + 0.5f) * sq;
                float t = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0f;
                if (t < 0) t = 0;
                if (t > 1) t = 1;
                float qx = ax + t * dx, qy = ay + t * dy;
                float d = (float) Math.sqrt((px - qx) * (px - qx) + (py - qy) * (py - qy));
                if (d <= sq * 0.75f) o[i] = lastClean[i];
            }
        }
        return !Arrays.equals(o, lastClean);
    }

    private void decodeAsync(final Image img, final Consumer<Detector.Board> cb) {
        busy = true;
        exec.execute(new Runnable() {
            @Override
            public void run() {
                Detector.Board b = null;
                try {
                    Image.Plane pl = img.getPlanes()[0];
                    ByteBuffer buf = pl.getBuffer();
                    int rs = pl.getRowStride(), ps = pl.getPixelStride();
                    int ih = img.getHeight();
                    int bw = rs / ps;
                    Bitmap bmp = Bitmap.createBitmap(bw, ih, Bitmap.Config.ARGB_8888);
                    bmp.copyPixelsFromBuffer(buf);
                    int[] px = new int[bw * ih];
                    bmp.getPixels(px, 0, bw, 0, 0, bw, ih);
                    bmp.recycle();
                    b = Detector.read(px, bw, ih);
                } catch (Throwable e) {
                    // ignore
                }
                try {
                    img.close();
                } catch (Throwable e) {
                    // ignore
                }
                final Detector.Board fb = b;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        busy = false;
                        if (running) cb.accept(fb);
                    }
                });
            }
        });
    }

    @Override
    public void onDestroy() {
        running = false;
        ui.removeCallbacksAndMessages(null);
        try {
            if (overlay != null) wm.removeView(overlay);
        } catch (Throwable e) {
            // ignore
        }
        try {
            if (web != null) {
                wm.removeView(web);
                web.destroy();
            }
        } catch (Throwable e) {
            // ignore
        }
        try {
            if (vd != null) vd.release();
        } catch (Throwable e) {
            // ignore
        }
        try {
            if (reader != null) reader.close();
        } catch (Throwable e) {
            // ignore
        }
        try {
            if (proj != null) proj.stop();
        } catch (Throwable e) {
            // ignore
        }
        exec.shutdown();
        super.onDestroy();
    }
}
