package com.chess.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

public class ArrowView extends View {
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hlPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path head = new Path();
    private final int[] loc = new int[2];

    private String info = "";
    private boolean has = false;
    private boolean hidden = false;
    private float fx, fy, tx, ty, sq;

    public ArrowView(Context c) {
        super(c);
        linePaint.setColor(0xCCFF6A00);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        fillPaint.setColor(0xCCFF6A00);
        fillPaint.setStyle(Paint.Style.FILL);
        hlPaint.setColor(0x66FFD400);
        hlPaint.setStyle(Paint.Style.FILL);
        textPaint.setColor(0xFFFFFFFF);
        textPaint.setTextSize(44f);
        bgPaint.setColor(0xAA000000);
    }

    public void setInfo(String s) {
        info = s == null ? "" : s;
        postInvalidate();
    }

    public void setArrow(float fromX, float fromY, float toX, float toY, float square) {
        fx = fromX;
        fy = fromY;
        tx = toX;
        ty = toY;
        sq = square;
        has = true;
        hidden = false;
        postInvalidate();
    }

    public void clearArrow() {
        has = false;
        hidden = false;
        postInvalidate();
    }

    public void setHidden(boolean h) {
        hidden = h;
        postInvalidate();
    }

    public boolean isShowing() {
        return has && !hidden;
    }

    @Override
    protected void onDraw(Canvas c) {
        getLocationOnScreen(loc);
        c.translate(-loc[0], -loc[1]);

        if (has && !hidden) {
            float h = sq * 0.5f;
            c.drawRect(fx - h, fy - h, fx + h, fy + h, hlPaint);
            c.drawRect(tx - h, ty - h, tx + h, ty + h, hlPaint);

            float dx = tx - fx, dy = ty - fy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 1f) {
                float ux = dx / len, uy = dy / len;
                float headLen = sq * 0.45f, headW = sq * 0.38f;
                linePaint.setStrokeWidth(sq * 0.16f);
                float sx = fx + ux * sq * 0.25f, sy = fy + uy * sq * 0.25f;
                float bx = tx - ux * headLen, by = ty - uy * headLen;
                c.drawLine(sx, sy, bx, by, linePaint);
                head.reset();
                head.moveTo(tx, ty);
                head.lineTo(bx - uy * headW, by + ux * headW);
                head.lineTo(bx + uy * headW, by - ux * headW);
                head.close();
                c.drawPath(head, fillPaint);
            }
        }

        if (!info.isEmpty()) {
            float w = textPaint.measureText(info);
            float x = 24f, y = loc[1] + 190f;
            RectF r = new RectF(x - 14, y - 52, x + w + 14, y + 20);
            c.drawRoundRect(r, 18f, 18f, bgPaint);
            c.drawText(info, x, y, textPaint);
        }
    }
}
