package com.chess.overlay;

import android.content.Context;

import java.io.PrintWriter;
import java.io.StringWriter;

final class Crash {
    static void install(Context c) {
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        final Context app = c.getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    save(app, sw.toString());
                } catch (Throwable x) {
                    // ignore
                }
                if (old != null) old.uncaughtException(t, e);
            }
        });
    }

    static void save(Context c, String s) {
        if (s == null) return;
        if (s.length() > 1200) s = s.substring(0, 1200);
        c.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().putString("last", s).commit();
    }

    static String last(Context c) {
        return c.getSharedPreferences("crash", Context.MODE_PRIVATE).getString("last", "");
    }

    static void clear(Context c) {
        c.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().clear().commit();
    }
}
