package com.chess.overlay;

final class Detector {
    static final class Board {
        int[] obs = new int[64];
        float x0, y0, s;
    }

    private static boolean near(int r, int g, int b, int R, int G, int B, int t) {
        return Math.abs(r - R) <= t && Math.abs(g - G) <= t && Math.abs(b - B) <= t;
    }

    private static boolean isBoard(int r, int g, int b) {
        return near(r, g, b, 238, 238, 210, 22) || near(r, g, b, 118, 150, 86, 22);
    }

    static Board read(int[] px, int w, int h) {
        int[] cols = new int[w];
        int[] rows = new int[h];
        for (int y = 0; y < h; y += 2) {
            int base = y * w;
            for (int x = 0; x < w; x += 2) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                if (isBoard(r, g, b)) {
                    cols[x]++;
                    rows[y]++;
                }
            }
        }
        int mc = 0, mr = 0;
        for (int x = 0; x < w; x++) if (cols[x] > mc) mc = cols[x];
        for (int y = 0; y < h; y++) if (rows[y] > mr) mr = rows[y];
        if (mc < 40) return null;
        int x0 = -1, x1 = -1, y0 = -1, y1 = -1;
        for (int x = 0; x < w; x++) {
            if (cols[x] > mc * 0.3) {
                if (x0 < 0) x0 = x;
                x1 = x;
            }
        }
        for (int y = 0; y < h; y++) {
            if (rows[y] > mr * 0.3) {
                if (y0 < 0) y0 = y;
                y1 = y;
            }
        }
        if (x0 < 0 || y0 < 0) return null;
        float bw = x1 - x0 + 2, bh = y1 - y0 + 2;
        if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh) || bw < 160) return null;
        float s = (bw + bh) / 2f;
        float sq = s / 8f;
        Board b = new Board();
        b.x0 = x0;
        b.y0 = y0;
        b.s = s;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                b.obs[r * 8 + c] = square(px, w, h, x0 + c * sq, y0 + r * sq, sq);
            }
        }
        return b;
    }

    private static int pixel(int[] px, int w, int h, int x, int y) {
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x >= w) x = w - 1;
        if (y >= h) y = h - 1;
        return px[y * w + x];
    }

    private static int square(int[] px, int w, int h, float sx, float sy, float sq) {
        int ins = Math.max(2, Math.round(sq * 0.07f));
        int p = Math.max(1, Math.round(sq * 0.03f));
        float[][] pts = {
                {sx + ins, sy + ins},
                {sx + sq - ins - p, sy + ins},
                {sx + ins, sy + sq - ins - p},
                {sx + sq - ins - p, sy + sq - ins - p}
        };
        float[][] cs = new float[4][3];
        for (int k = 0; k < 4; k++) {
            float sr = 0, sg = 0, sb = 0;
            int n = 0;
            int pxx = Math.round(pts[k][0]), pyy = Math.round(pts[k][1]);
            for (int a = 0; a < p; a++) {
                for (int b2 = 0; b2 < p; b2++) {
                    int c = pixel(px, w, h, pxx + b2, pyy + a);
                    sr += (c >> 16) & 255;
                    sg += (c >> 8) & 255;
                    sb += c & 255;
                    n++;
                }
            }
            cs[k][0] = sr / n;
            cs[k][1] = sg / n;
            cs[k][2] = sb / n;
        }
        float bd = 1e9f;
        int bi = 0, bj = 1;
        for (int a = 0; a < 4; a++) {
            for (int b2 = a + 1; b2 < 4; b2++) {
                float dd = Math.abs(cs[a][0] - cs[b2][0]) + Math.abs(cs[a][1] - cs[b2][1]) + Math.abs(cs[a][2] - cs[b2][2]);
                if (dd < bd) {
                    bd = dd;
                    bi = a;
                    bj = b2;
                }
            }
        }
        float bgr = (cs[bi][0] + cs[bj][0]) / 2f;
        float bgg = (cs[bi][1] + cs[bj][1]) / 2f;
        float bgb = (cs[bi][2] + cs[bj][2]) / 2f;
        int xa = Math.round(sx + sq * 0.15f), xb = Math.round(sx + sq * 0.85f);
        int ya = Math.round(sy + sq * 0.15f), yb = Math.round(sy + sq * 0.85f);
        int[] hist = new int[256];
        int tot = 0, cnt = 0;
        for (int y = ya; y < yb; y += 2) {
            for (int x = xa; x < xb; x += 2) {
                int c = pixel(px, w, h, x, y);
                int r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
                tot++;
                float dist = Math.abs(r - bgr) + Math.abs(g - bgg) + 1.5f * Math.abs(bl - bgb);
                if (dist > 40f) {
                    cnt++;
                    int luma = Math.round(0.299f * r + 0.587f * g + 0.114f * bl);
                    if (luma > 255) luma = 255;
                    hist[luma]++;
                }
            }
        }
        if (tot == 0 || (float) cnt / tot < 0.25f) return 0;
        float half = cnt / 2f;
        int acc = 0, med = 0;
        for (int k = 0; k < 256; k++) {
            acc += hist[k];
            if (acc >= half) {
                med = k;
                break;
            }
        }
        return med < 150 ? 2 : 1;
    }
}
