package com.chess.overlay;

final class Detector {
    static final class Board {
        int[] obs = new int[64];
        float x0, y0, s;
        boolean needStart;
        boolean textured;
    }

    static final class Geo {
        float x0, y0, s;
    }

    static final class Calib {
        boolean[] pal = new boolean[4096];
        float th, lumaTh, gx, gy, gs;
    }

    static volatile Calib calib = null;
    static volatile boolean needRelearn = false;
    static volatile boolean forceDeep = false;

    private static boolean near(int r, int g, int b, int R, int G, int B, int t) {
        return Math.abs(r - R) <= t && Math.abs(g - G) <= t && Math.abs(b - B) <= t;
    }

    private static boolean isBoard(int r, int g, int b) {
        return near(r, g, b, 238, 238, 210, 22) || near(r, g, b, 118, 150, 86, 22);
    }

    static volatile boolean lastBlack = false;

    static Board read(int[] px, int w, int h) {
        lastBlack = mostlyBlack(px, w, h);
        if (lastBlack) return null;
        Geo g = geoDefault(px, w, h);
        if (g == null) g = geoAdaptive(px, w, h);
        if (g == null) g = geoParity(px, w, h);
        if (g == null) return null;
        Board b = new Board();
        b.x0 = g.x0;
        b.y0 = g.y0;
        b.s = g.s;
        if (!isTextured(px, w, h, g)) {
            float sq = g.s / 8f;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    b.obs[r * 8 + c] = square(px, w, h, g.x0 + c * sq, g.y0 + r * sq, sq);
                }
            }
            return b;
        }
        b.textured = true;
        Calib c = calib;
        if (c != null && !(Math.abs(c.gx - g.x0) < 4 && Math.abs(c.gy - g.y0) < 4 && Math.abs(c.gs - g.s) < 6)) {
            c = null;
        }
        if (c == null || needRelearn) {
            Calib n = learn(px, w, h, g);
            if (n != null && startLike(classify(px, w, h, g, n))) {
                calib = n;
                needRelearn = false;
                c = n;
            }
        }
        if (c == null) {
            b.needStart = true;
            return b;
        }
        b.obs = classify(px, w, h, g, c);
        return b;
    }

    private static boolean mostlyBlack(int[] px, int w, int h) {
        int total = w * h;
        int step = Math.max(1, total / 500);
        int dark = 0, n = 0;
        for (int i = 0; i < total; i += step) {
            n++;
            if ((px[i] & 0xFFFFFF) < 0x080808) dark++;
        }
        return n > 0 && dark >= n * 0.97;
    }

    private static Geo geoDefault(int[] px, int w, int h) {
        int[] cols = new int[w];
        int[] rows = new int[h];
        for (int y = 0; y < h; y += 2) {
            int base = y * w;
            for (int x = 0; x < w; x += 2) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                if (isBoard(r, g, b)) {
                    cols[x]++;
                    rows[y]++;
                }
            }
        }
        int mc = 0, mr = 0;
        for (int x = 0; x < w; x++) if (cols[x] > mc) mc = cols[x];
        for (int y = 0; y < h; y++) if (rows[y] > mr) mr = rows[y];
        if (mc < 40) return null;
        int x0 = -1, x1 = -1, y0 = -1, y1 = -1;
        for (int x = 0; x < w; x++) {
            if (cols[x] > mc * 0.3) {
                if (x0 < 0) x0 = x;
                x1 = x;
            }
        }
        for (int y = 0; y < h; y++) {
            if (rows[y] > mr * 0.3) {
                if (y0 < 0) y0 = y;
                y1 = y;
            }
        }
        if (x0 < 0 || y0 < 0) return null;
        float bw = x1 - x0 + 2, bh = y1 - y0 + 2;
        if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh) || bw < 160) return null;
        float s = (bw + bh) / 2f;
        Geo b = new Geo();
        b.x0 = x0;
        b.y0 = y0;
        b.s = s;
        return b;
    }


    /* поиск доски любой цветовой темы: две самые частые «шахматные» краски, образующие квадрат 8x8 */
    private static Geo geoAdaptive(int[] px, int w, int h) {
        int[] cnt = new int[32768];
        long[] sr = new long[32768], sg = new long[32768], sb = new long[32768];
        for (int y = 0; y < h; y += 3) {
            int base = y * w;
            for (int x = 0; x < w; x += 3) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                int k = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
                cnt[k]++;
                sr[k] += r;
                sg[k] += g;
                sb[k] += b;
            }
        }
        boolean[] used = new boolean[32768];
        float[][] cc = new float[10][3];
        int nc = 0;
        for (int t = 0; t < 40; t++) {
            int bi = -1, bc = 0;
            for (int k = 0; k < 32768; k++) {
                if (!used[k] && cnt[k] > bc) {
                    bc = cnt[k];
                    bi = k;
                }
            }
            if (bi < 0 || bc < 50) break;
            used[bi] = true;
            float r = sr[bi] / (float) cnt[bi], g = sg[bi] / (float) cnt[bi], b = sb[bi] / (float) cnt[bi];
            boolean dup = false;
            for (int c = 0; c < nc; c++) {
                if (Math.abs(cc[c][0] - r) + Math.abs(cc[c][1] - g) + Math.abs(cc[c][2] - b) <= 36) {
                    dup = true;
                    break;
                }
            }
            if (!dup && nc < 10) {
                cc[nc][0] = r;
                cc[nc][1] = g;
                cc[nc][2] = b;
                nc++;
            }
        }
        if (nc < 2) return null;
        int[][] colsK = new int[nc][w];
        int[][] rowsK = new int[nc][h];
        for (int y = 0; y < h; y += 2) {
            int base = y * w;
            for (int x = 0; x < w; x += 2) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                for (int c = 0; c < nc; c++) {
                    if (Math.abs(r - cc[c][0]) <= 18 && Math.abs(g - cc[c][1]) <= 18 && Math.abs(b - cc[c][2]) <= 18) {
                        colsK[c][x]++;
                        rowsK[c][y]++;
                        break;
                    }
                }
            }
        }
        Geo best = null;
        float bestArea = 0;
        for (int a = 0; a < nc; a++) {
            for (int b = a + 1; b < nc; b++) {
                float la = 0.299f * cc[a][0] + 0.587f * cc[a][1] + 0.114f * cc[a][2];
                float lb = 0.299f * cc[b][0] + 0.587f * cc[b][1] + 0.114f * cc[b][2];
                if (Math.abs(la - lb) < 20f) continue;
                int[] cols = new int[w];
                int[] rows = new int[h];
                int mc = 0, mr = 0;
                for (int x = 0; x < w; x++) {
                    cols[x] = colsK[a][x] + colsK[b][x];
                    if (cols[x] > mc) mc = cols[x];
                }
                for (int y = 0; y < h; y++) {
                    rows[y] = rowsK[a][y] + rowsK[b][y];
                    if (rows[y] > mr) mr = rows[y];
                }
                if (mc < 40) continue;
                int x0 = -1, x1 = -1, y0 = -1, y1 = -1;
                for (int x = 0; x < w; x++) {
                    if (cols[x] > mc * 0.3) {
                        if (x0 < 0) x0 = x;
                        x1 = x;
                    }
                }
                for (int y = 0; y < h; y++) {
                    if (rows[y] > mr * 0.3) {
                        if (y0 < 0) y0 = y;
                        y1 = y;
                    }
                }
                if (x0 < 0 || y0 < 0) continue;
                float bw = x1 - x0 + 2, bh = y1 - y0 + 2;
                if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh) || bw < 160) continue;
                float s = (bw + bh) / 2f;
                float sq = s / 8f;
                if (!checker(px, w, h, x0, y0, sq, cc[a], cc[b])) continue;
                if (s * s > bestArea) {
                    bestArea = s * s;
                    Geo bd = new Geo();
                    bd.x0 = x0;
                    bd.y0 = y0;
                    bd.s = s;
                    best = bd;
                }
            }
        }
        return best;
    }

    private static boolean nearColor(int p, float[] c) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return Math.abs(r - c[0]) <= 26 && Math.abs(g - c[1]) <= 26 && Math.abs(b - c[2]) <= 26;
    }

    private static boolean checker(int[] px, int w, int h, float x0, float y0, float sq, float[] ca, float[] cb) {
        int o1 = 0, o2 = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int p1 = pixel(px, w, h, Math.round(x0 + c * sq + sq * 0.12f), Math.round(y0 + r * sq + sq * 0.88f));
                int p2 = pixel(px, w, h, Math.round(x0 + c * sq + sq * 0.88f), Math.round(y0 + r * sq + sq * 0.12f));
                boolean even = ((r + c) % 2) == 0;
                float[] e1 = even ? ca : cb;
                float[] e2 = even ? cb : ca;
                if (nearColor(p1, e1) || nearColor(p2, e1)) o1++;
                if (nearColor(p1, e2) || nearColor(p2, e2)) o2++;
            }
        }
        return Math.max(o1, o2) >= 45;
    }


    /* ---------- доска с текстурой: поиск по шахматному чередованию яркости ---------- */

    private static float meanRect(int[] ii, int W1, int x, int y, int rw, int rh) {
        long s = (long) ii[(y + rh) * W1 + x + rw] - ii[y * W1 + x + rw] - ii[(y + rh) * W1 + x] + ii[y * W1 + x];
        return s / (float) (rw * rh);
    }

    private static int evalParity(int[] ii, int W1, int w, int h, float x0, float y0, float S) {
        if (x0 < 0 || y0 < 0 || x0 + S > w || y0 + S > h) return 0;
        float sq = S / 8f;
        int p = Math.max(2, Math.round(sq * 0.08f));
        int in = Math.max(1, Math.round(sq * 0.04f));
        float[] v = new float[64];
        float[] t = new float[4];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int sx = Math.round(x0 + c * sq), sy = Math.round(y0 + r * sq);
                int ex = Math.round(x0 + (c + 1) * sq), ey = Math.round(y0 + (r + 1) * sq);
                t[0] = meanRect(ii, W1, sx + in, sy + in, p, p);
                t[1] = meanRect(ii, W1, ex - in - p, sy + in, p, p);
                t[2] = meanRect(ii, W1, sx + in, ey - in - p, p, p);
                t[3] = meanRect(ii, W1, ex - in - p, ey - in - p, p, p);
                java.util.Arrays.sort(t);
                v[r * 8 + c] = (t[1] + t[2]) / 2f;
            }
        }
        float[] e = new float[32], o = new float[32];
        int ie = 0, io = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                if (((r + c) & 1) == 0) e[ie++] = v[r * 8 + c];
                else o[io++] = v[r * 8 + c];
            }
        }
        java.util.Arrays.sort(e);
        java.util.Arrays.sort(o);
        float medE = (e[15] + e[16]) / 2f, medO = (o[15] + o[16]) / 2f;
        float contrast = Math.abs(medE - medO);
        if (contrast < 8f) return 0;
        float thr = (medE + medO) / 2f;
        boolean eHigh = medE > medO;
        int cnt = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                boolean high = v[r * 8 + c] > thr;
                boolean even = ((r + c) & 1) == 0;
                if (even ? (high == eHigh) : (high != eHigh)) cnt++;
            }
        }
        return cnt * 100 + Math.min(99, (int) contrast);
    }

    private static Geo geoParity(int[] px, int w, int h) {
        int W1 = w + 1;
        int[] ii = new int[W1 * (h + 1)];
        for (int y = 0; y < h; y++) {
            int row = 0;
            int base = y * w;
            for (int x = 0; x < w; x++) {
                int p = px[base + x];
                int l = (int) (0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255));
                row += l;
                ii[(y + 1) * W1 + x + 1] = ii[y * W1 + x + 1] + row;
            }
        }
        float bx = 0, by = 0, bs = 0;
        int best = 0;
        // 1) доска во всю ширину
        float S = w;
        for (int y = 0; y + S <= h; y += 4) {
            int sc = evalParity(ii, W1, w, h, 0, y, S);
            if (sc > best) {
                best = sc;
                bx = 0;
                by = y;
                bs = S;
            }
        }
        // 2) глубокий поиск (по кнопке «обновить»)
        if (best / 100 < 58 && forceDeep) {
            forceDeep = false;
            best = 0;
            for (float s2 = w * 0.45f; s2 <= w; s2 += 12f) {
                for (float x = 0; x + s2 <= w; x += 12f) {
                    for (float y = 0; y + s2 <= h; y += 12f) {
                        int sc = evalParity(ii, W1, w, h, x, y, s2);
                        if (sc > best) {
                            best = sc;
                            bx = x;
                            by = y;
                            bs = s2;
                        }
                    }
                }
            }
        }
        if (best / 100 < 58) return null;
        // уточнение
        for (int pass = 0; pass < 2; pass++) {
            int step = pass == 0 ? 3 : 1;
            float cx = bx, cy = by, cs = bs;
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    for (int ds = -2; ds <= 2; ds++) {
                        float nx = cx + dx * step, ny = cy + dy * step, ns = cs + ds * step;
                        int sc = evalParity(ii, W1, w, h, nx, ny, ns);
                        if (sc > best) {
                            best = sc;
                            bx = nx;
                            by = ny;
                            bs = ns;
                        }
                    }
                }
            }
        }
        Geo g = new Geo();
        g.x0 = bx;
        g.y0 = by;
        g.s = bs;
        return g;
    }

    private static boolean isTextured(int[] px, int w, int h, Geo g) {
        float sq = g.s / 8f;
        float[] stds = new float[64];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                float sx = g.x0 + c * sq, sy = g.y0 + r * sq;
                int xa = Math.round(sx + sq * 0.2f), xb = Math.round(sx + sq * 0.8f);
                int ya = Math.round(sy + sq * 0.2f), yb = Math.round(sy + sq * 0.8f);
                double sum = 0, sum2 = 0;
                int n = 0;
                for (int y = ya; y < yb; y += 2) {
                    for (int x = xa; x < xb; x += 2) {
                        int p = pixel(px, w, h, x, y);
                        double l = 0.299 * ((p >> 16) & 255) + 0.587 * ((p >> 8) & 255) + 0.114 * (p & 255);
                        sum += l;
                        sum2 += l * l;
                        n++;
                    }
                }
                double mean = sum / Math.max(1, n);
                stds[r * 8 + c] = (float) Math.sqrt(Math.max(0, sum2 / Math.max(1, n) - mean * mean));
            }
        }
        java.util.Arrays.sort(stds);
        return stds[16] > 5f;
    }

    /* ---------- обучение «пустой клетки» по начальной расстановке ---------- */

    private static int offBin(int p, float[] bg) {
        int qr = (((p >> 16) & 255) - Math.round(bg[0]) + 128) >> 4;
        int qg = (((p >> 8) & 255) - Math.round(bg[1]) + 128) >> 4;
        int qb = ((p & 255) - Math.round(bg[2]) + 128) >> 4;
        if (qr < 0) qr = 0;
        if (qr > 15) qr = 15;
        if (qg < 0) qg = 0;
        if (qg > 15) qg = 15;
        if (qb < 0) qb = 0;
        if (qb > 15) qb = 15;
        return (qr << 8) | (qg << 4) | qb;
    }

    private static boolean[] dilate(boolean[] pal) {
        boolean[] out = new boolean[4096];
        for (int k = 0; k < 4096; k++) {
            if (!pal[k]) continue;
            int qr = k >> 8, qg = (k >> 4) & 15, qb = k & 15;
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    for (int c = -1; c <= 1; c++) {
                        int r2 = qr + a, g2 = qg + b, b2 = qb + c;
                        if (r2 < 0 || r2 > 15 || g2 < 0 || g2 > 15 || b2 < 0 || b2 > 15) continue;
                        out[(r2 << 8) | (g2 << 4) | b2] = true;
                    }
                }
            }
        }
        return out;
    }

    /* out[0] = доля «не фоновых» пикселей, out[1] = средняя яркость этих пикселей */
    private static void sqStats(int[] px, int w, int h, float sx, float sy, float sq, float[] bg, boolean[] pal, float[] out) {
        int xa = Math.round(sx + sq * 0.15f), xb = Math.round(sx + sq * 0.85f);
        int ya = Math.round(sy + sq * 0.15f), yb = Math.round(sy + sq * 0.85f);
        int tot = 0, cnt = 0;
        double lum = 0;
        for (int y = ya; y < yb; y += 2) {
            for (int x = xa; x < xb; x += 2) {
                int p = pixel(px, w, h, x, y);
                tot++;
                if (!pal[offBin(p, bg)]) {
                    cnt++;
                    lum += 0.299 * ((p >> 16) & 255) + 0.587 * ((p >> 8) & 255) + 0.114 * (p & 255);
                }
            }
        }
        out[0] = tot == 0 ? 0f : (float) cnt / tot;
        out[1] = cnt == 0 ? 0f : (float) (lum / cnt);
    }

    private static Calib learn(int[] px, int w, int h, Geo g) {
        float sq = g.s / 8f;
        float[][] bgs = new float[64][];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                bgs[r * 8 + c] = cornerBg(px, w, h, g.x0 + c * sq, g.y0 + r * sq, sq);
            }
        }
        int[] pres = new int[4096];
        int nE = 0;
        for (int r = 2; r <= 5; r++) {
            for (int c = 0; c < 8; c++) {
                int[] cnt = new int[4096];
                float sx = g.x0 + c * sq, sy = g.y0 + r * sq;
                int xa = Math.round(sx + sq * 0.15f), xb = Math.round(sx + sq * 0.85f);
                int ya = Math.round(sy + sq * 0.15f), yb = Math.round(sy + sq * 0.85f);
                for (int y = ya; y < yb; y += 2) {
                    for (int x = xa; x < xb; x += 2) {
                        cnt[offBin(pixel(px, w, h, x, y), bgs[r * 8 + c])]++;
                    }
                }
                for (int k = 0; k < 4096; k++) if (cnt[k] >= 2) pres[k]++;
                nE++;
            }
        }
        boolean[] pal = new boolean[4096];
        int need = Math.max(2, (int) (0.375f * nE));
        for (int k = 0; k < 4096; k++) pal[k] = pres[k] >= need;
        boolean[] dil = dilate(pal);
        float[] fE = new float[32], fP = new float[32];
        int ie = 0, ip = 0, nt = 0, nb = 0;
        float lt = 0, lb = 0;
        float[] out = new float[2];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                sqStats(px, w, h, g.x0 + c * sq, g.y0 + r * sq, sq, bgs[r * 8 + c], dil, out);
                if (r >= 2 && r <= 5) {
                    fE[ie++] = out[0];
                } else {
                    fP[ip++] = out[0];
                    if (r < 2) {
                        lt += out[1];
                        nt++;
                    } else {
                        lb += out[1];
                        nb++;
                    }
                }
            }
        }
        java.util.Arrays.sort(fE);
        java.util.Arrays.sort(fP);
        float e85 = fE[(int) (0.85f * 31)], p15 = fP[(int) (0.15f * 31)];
        if (!(e85 < p15) || p15 < 0.10f) return null;
        float lT = lt / nt, lB = lb / nb;
        if (Math.abs(lT - lB) < 25f) return null;
        Calib k = new Calib();
        k.pal = dil;
        k.th = (e85 + p15) / 2f;
        k.lumaTh = (lT + lB) / 2f;
        k.gx = g.x0;
        k.gy = g.y0;
        k.gs = g.s;
        return k;
    }

    private static int[] classify(int[] px, int w, int h, Geo g, Calib c) {
        float sq = g.s / 8f;
        int[] o = new int[64];
        float[] out = new float[2];
        for (int r = 0; r < 8; r++) {
            for (int col = 0; col < 8; col++) {
                float sx = g.x0 + col * sq, sy = g.y0 + r * sq;
                float[] bg = cornerBg(px, w, h, sx, sy, sq);
                sqStats(px, w, h, sx, sy, sq, bg, c.pal, out);
                if (out[0] > c.th) o[r * 8 + col] = out[1] > c.lumaTh ? 1 : 2;
            }
        }
        return o;
    }

    private static boolean startLike(int[] o) {
        int best = 99;
        for (int top = 1; top <= 2; top++) {
            int bot = 3 - top, mm = 0;
            for (int i = 0; i < 64; i++) {
                int r = i / 8;
                int exp = r < 2 ? top : (r > 5 ? bot : 0);
                if (o[i] != exp) mm++;
            }
            if (mm < best) best = mm;
        }
        return best <= 2;
    }

    private static int pixel(int[] px, int w, int h, int x, int y) {
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x >= w) x = w - 1;
        if (y >= h) y = h - 1;
        return px[y * w + x];
    }

    private static float[] cornerBg(int[] px, int w, int h, float sx, float sy, float sq) {
        int ins = Math.max(2, Math.round(sq * 0.07f));
        int p = Math.max(1, Math.round(sq * 0.03f));
        float[][] pts = {
                {sx + ins, sy + ins},
                {sx + sq - ins - p, sy + ins},
                {sx + ins, sy + sq - ins - p},
                {sx + sq - ins - p, sy + sq - ins - p}
        };
        float[][] cs = new float[4][3];
        for (int k = 0; k < 4; k++) {
            float sr = 0, sg = 0, sb = 0;
            int n = 0;
            int pxx = Math.round(pts[k][0]), pyy = Math.round(pts[k][1]);
            for (int a = 0; a < p; a++) {
                for (int b2 = 0; b2 < p; b2++) {
                    int c = pixel(px, w, h, pxx + b2, pyy + a);
                    sr += (c >> 16) & 255;
                    sg += (c >> 8) & 255;
                    sb += c & 255;
                    n++;
                }
            }
            cs[k][0] = sr / n;
            cs[k][1] = sg / n;
            cs[k][2] = sb / n;
        }
        float bd = 1e9f;
        int bi = 0, bj = 1;
        for (int a = 0; a < 4; a++) {
            for (int b2 = a + 1; b2 < 4; b2++) {
                float dd = Math.abs(cs[a][0] - cs[b2][0]) + Math.abs(cs[a][1] - cs[b2][1]) + Math.abs(cs[a][2] - cs[b2][2]);
                if (dd < bd) {
                    bd = dd;
                    bi = a;
                    bj = b2;
                }
            }
        }
        return new float[]{(cs[bi][0] + cs[bj][0]) / 2f, (cs[bi][1] + cs[bj][1]) / 2f, (cs[bi][2] + cs[bj][2]) / 2f};
    }

    private static int square(int[] px, int w, int h, float sx, float sy, float sq) {
        float[] bgv = cornerBg(px, w, h, sx, sy, sq);
        float bgr = bgv[0], bgg = bgv[1], bgb = bgv[2];
        int xa = Math.round(sx + sq * 0.15f), xb = Math.round(sx + sq * 0.85f);
        int ya = Math.round(sy + sq * 0.15f), yb = Math.round(sy + sq * 0.85f);
        int[] hist = new int[256];
        int tot = 0, cnt = 0;
        for (int y = ya; y < yb; y += 2) {
            for (int x = xa; x < xb; x += 2) {
                int c = pixel(px, w, h, x, y);
                int r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
                tot++;
                float dist = Math.abs(r - bgr) + Math.abs(g - bgg) + 1.5f * Math.abs(bl - bgb);
                if (dist > 28f) {
                    cnt++;
                    int luma = Math.round(0.299f * r + 0.587f * g + 0.114f * bl);
                    if (luma > 255) luma = 255;
                    hist[luma]++;
                }
            }
        }
        if (tot == 0 || (float) cnt / tot < 0.22f) return 0;
        float half = cnt / 2f;
        int acc = 0, med = 0;
        for (int k = 0; k < 256; k++) {
            acc += hist[k];
            if (acc >= half) {
                med = k;
                break;
            }
        }
        return med < 150 ? 2 : 1;
    }
}
