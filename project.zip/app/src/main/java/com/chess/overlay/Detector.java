package com.chess.overlay;

final class Detector {
    static final class Board {
        int[] obs = new int[64];
        float x0, y0, s;
    }

    private static boolean near(int r, int g, int b, int R, int G, int B, int t) {
        return Math.abs(r - R) <= t && Math.abs(g - G) <= t && Math.abs(b - B) <= t;
    }

    private static boolean isBoard(int r, int g, int b) {
        return near(r, g, b, 238, 238, 210, 22) || near(r, g, b, 118, 150, 86, 22);
    }

    static volatile boolean lastBlack = false;

    static Board read(int[] px, int w, int h) {
        lastBlack = mostlyBlack(px, w, h);
        if (lastBlack) return null;
        Board b = readDefault(px, w, h);
        if (b != null) return b;
        return readAdaptive(px, w, h);
    }

    private static boolean mostlyBlack(int[] px, int w, int h) {
        int total = w * h;
        int step = Math.max(1, total / 500);
        int dark = 0, n = 0;
        for (int i = 0; i < total; i += step) {
            n++;
            if ((px[i] & 0xFFFFFF) < 0x080808) dark++;
        }
        return n > 0 && dark >= n * 0.97;
    }

    private static Board readDefault(int[] px, int w, int h) {
        int[] cols = new int[w];
        int[] rows = new int[h];
        for (int y = 0; y < h; y += 2) {
            int base = y * w;
            for (int x = 0; x < w; x += 2) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                if (isBoard(r, g, b)) {
                    cols[x]++;
                    rows[y]++;
                }
            }
        }
        int mc = 0, mr = 0;
        for (int x = 0; x < w; x++) if (cols[x] > mc) mc = cols[x];
        for (int y = 0; y < h; y++) if (rows[y] > mr) mr = rows[y];
        if (mc < 40) return null;
        int x0 = -1, x1 = -1, y0 = -1, y1 = -1;
        for (int x = 0; x < w; x++) {
            if (cols[x] > mc * 0.3) {
                if (x0 < 0) x0 = x;
                x1 = x;
            }
        }
        for (int y = 0; y < h; y++) {
            if (rows[y] > mr * 0.3) {
                if (y0 < 0) y0 = y;
                y1 = y;
            }
        }
        if (x0 < 0 || y0 < 0) return null;
        float bw = x1 - x0 + 2, bh = y1 - y0 + 2;
        if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh) || bw < 160) return null;
        float s = (bw + bh) / 2f;
        float sq = s / 8f;
        Board b = new Board();
        b.x0 = x0;
        b.y0 = y0;
        b.s = s;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                b.obs[r * 8 + c] = square(px, w, h, x0 + c * sq, y0 + r * sq, sq);
            }
        }
        return b;
    }


    /* поиск доски любой цветовой темы: две самые частые «шахматные» краски, образующие квадрат 8x8 */
    private static Board readAdaptive(int[] px, int w, int h) {
        int[] cnt = new int[32768];
        long[] sr = new long[32768], sg = new long[32768], sb = new long[32768];
        for (int y = 0; y < h; y += 3) {
            int base = y * w;
            for (int x = 0; x < w; x += 3) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                int k = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
                cnt[k]++;
                sr[k] += r;
                sg[k] += g;
                sb[k] += b;
            }
        }
        boolean[] used = new boolean[32768];
        float[][] cc = new float[10][3];
        int nc = 0;
        for (int t = 0; t < 40; t++) {
            int bi = -1, bc = 0;
            for (int k = 0; k < 32768; k++) {
                if (!used[k] && cnt[k] > bc) {
                    bc = cnt[k];
                    bi = k;
                }
            }
            if (bi < 0 || bc < 50) break;
            used[bi] = true;
            float r = sr[bi] / (float) cnt[bi], g = sg[bi] / (float) cnt[bi], b = sb[bi] / (float) cnt[bi];
            boolean dup = false;
            for (int c = 0; c < nc; c++) {
                if (Math.abs(cc[c][0] - r) + Math.abs(cc[c][1] - g) + Math.abs(cc[c][2] - b) <= 36) {
                    dup = true;
                    break;
                }
            }
            if (!dup && nc < 10) {
                cc[nc][0] = r;
                cc[nc][1] = g;
                cc[nc][2] = b;
                nc++;
            }
        }
        if (nc < 2) return null;
        int[][] colsK = new int[nc][w];
        int[][] rowsK = new int[nc][h];
        for (int y = 0; y < h; y += 2) {
            int base = y * w;
            for (int x = 0; x < w; x += 2) {
                int p = px[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                for (int c = 0; c < nc; c++) {
                    if (Math.abs(r - cc[c][0]) <= 18 && Math.abs(g - cc[c][1]) <= 18 && Math.abs(b - cc[c][2]) <= 18) {
                        colsK[c][x]++;
                        rowsK[c][y]++;
                        break;
                    }
                }
            }
        }
        Board best = null;
        float bestArea = 0;
        for (int a = 0; a < nc; a++) {
            for (int b = a + 1; b < nc; b++) {
                float la = 0.299f * cc[a][0] + 0.587f * cc[a][1] + 0.114f * cc[a][2];
                float lb = 0.299f * cc[b][0] + 0.587f * cc[b][1] + 0.114f * cc[b][2];
                if (Math.abs(la - lb) < 20f) continue;
                int[] cols = new int[w];
                int[] rows = new int[h];
                int mc = 0, mr = 0;
                for (int x = 0; x < w; x++) {
                    cols[x] = colsK[a][x] + colsK[b][x];
                    if (cols[x] > mc) mc = cols[x];
                }
                for (int y = 0; y < h; y++) {
                    rows[y] = rowsK[a][y] + rowsK[b][y];
                    if (rows[y] > mr) mr = rows[y];
                }
                if (mc < 40) continue;
                int x0 = -1, x1 = -1, y0 = -1, y1 = -1;
                for (int x = 0; x < w; x++) {
                    if (cols[x] > mc * 0.3) {
                        if (x0 < 0) x0 = x;
                        x1 = x;
                    }
                }
                for (int y = 0; y < h; y++) {
                    if (rows[y] > mr * 0.3) {
                        if (y0 < 0) y0 = y;
                        y1 = y;
                    }
                }
                if (x0 < 0 || y0 < 0) continue;
                float bw = x1 - x0 + 2, bh = y1 - y0 + 2;
                if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh) || bw < 160) continue;
                float s = (bw + bh) / 2f;
                float sq = s / 8f;
                if (!checker(px, w, h, x0, y0, sq, cc[a], cc[b])) continue;
                if (s * s > bestArea) {
                    bestArea = s * s;
                    Board bd = new Board();
                    bd.x0 = x0;
                    bd.y0 = y0;
                    bd.s = s;
                    best = bd;
                }
            }
        }
        if (best == null) return null;
        float sq = best.s / 8f;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                best.obs[r * 8 + c] = square(px, w, h, best.x0 + c * sq, best.y0 + r * sq, sq);
            }
        }
        return best;
    }

    private static boolean nearColor(int p, float[] c) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return Math.abs(r - c[0]) <= 26 && Math.abs(g - c[1]) <= 26 && Math.abs(b - c[2]) <= 26;
    }

    private static boolean checker(int[] px, int w, int h, float x0, float y0, float sq, float[] ca, float[] cb) {
        int o1 = 0, o2 = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int p1 = pixel(px, w, h, Math.round(x0 + c * sq + sq * 0.12f), Math.round(y0 + r * sq + sq * 0.88f));
                int p2 = pixel(px, w, h, Math.round(x0 + c * sq + sq * 0.88f), Math.round(y0 + r * sq + sq * 0.12f));
                boolean even = ((r + c) % 2) == 0;
                float[] e1 = even ? ca : cb;
                float[] e2 = even ? cb : ca;
                if (nearColor(p1, e1) || nearColor(p2, e1)) o1++;
                if (nearColor(p1, e2) || nearColor(p2, e2)) o2++;
            }
        }
        return Math.max(o1, o2) >= 45;
    }

    private static int pixel(int[] px, int w, int h, int x, int y) {
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x >= w) x = w - 1;
        if (y >= h) y = h - 1;
        return px[y * w + x];
    }

    private static int square(int[] px, int w, int h, float sx, float sy, float sq) {
        int ins = Math.max(2, Math.round(sq * 0.07f));
        int p = Math.max(1, Math.round(sq * 0.03f));
        float[][] pts = {
                {sx + ins, sy + ins},
                {sx + sq - ins - p, sy + ins},
                {sx + ins, sy + sq - ins - p},
                {sx + sq - ins - p, sy + sq - ins - p}
        };
        float[][] cs = new float[4][3];
        for (int k = 0; k < 4; k++) {
            float sr = 0, sg = 0, sb = 0;
            int n = 0;
            int pxx = Math.round(pts[k][0]), pyy = Math.round(pts[k][1]);
            for (int a = 0; a < p; a++) {
                for (int b2 = 0; b2 < p; b2++) {
                    int c = pixel(px, w, h, pxx + b2, pyy + a);
                    sr += (c >> 16) & 255;
                    sg += (c >> 8) & 255;
                    sb += c & 255;
                    n++;
                }
            }
            cs[k][0] = sr / n;
            cs[k][1] = sg / n;
            cs[k][2] = sb / n;
        }
        float bd = 1e9f;
        int bi = 0, bj = 1;
        for (int a = 0; a < 4; a++) {
            for (int b2 = a + 1; b2 < 4; b2++) {
                float dd = Math.abs(cs[a][0] - cs[b2][0]) + Math.abs(cs[a][1] - cs[b2][1]) + Math.abs(cs[a][2] - cs[b2][2]);
                if (dd < bd) {
                    bd = dd;
                    bi = a;
                    bj = b2;
                }
            }
        }
        float bgr = (cs[bi][0] + cs[bj][0]) / 2f;
        float bgg = (cs[bi][1] + cs[bj][1]) / 2f;
        float bgb = (cs[bi][2] + cs[bj][2]) / 2f;
        int xa = Math.round(sx + sq * 0.15f), xb = Math.round(sx + sq * 0.85f);
        int ya = Math.round(sy + sq * 0.15f), yb = Math.round(sy + sq * 0.85f);
        int[] hist = new int[256];
        int tot = 0, cnt = 0;
        for (int y = ya; y < yb; y += 2) {
            for (int x = xa; x < xb; x += 2) {
                int c = pixel(px, w, h, x, y);
                int r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
                tot++;
                float dist = Math.abs(r - bgr) + Math.abs(g - bgg) + 1.5f * Math.abs(bl - bgb);
                if (dist > 28f) {
                    cnt++;
                    int luma = Math.round(0.299f * r + 0.587f * g + 0.114f * bl);
                    if (luma > 255) luma = 255;
                    hist[luma]++;
                }
            }
        }
        if (tot == 0 || (float) cnt / tot < 0.22f) return 0;
        float half = cnt / 2f;
        int acc = 0, med = 0;
        for (int k = 0; k < 256; k++) {
            acc += hist[k];
            if (acc >= half) {
                med = k;
                break;
            }
        }
        return med < 150 ? 2 : 1;
    }
}
