package com.chess.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1;
    private static final int REQ_PROJECTION = 2;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 3, pad, pad);

        TextView info = new TextView(this);
        info.setTextSize(17f);
        info.setText("Шахматный оверлей\n\n"
                + "1. Нажми «Запустить» и разреши показ поверх других окон и запись экрана.\n"
                + "2. Открой Chess.com и начни партию. Стрелка на доске покажет лучший ход.\n"
                + "3. Начинай с самого начала партии — программа следит за ходами сама.\n\n"
                + "Нужна зелёная доска Chess.com, целиком на экране.");
        root.addView(info);

        Button start = new Button(this);
        start.setText("▶ Запустить");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startFlow();
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("■ Остановить");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, OverlayService.class));
                Toast.makeText(MainActivity.this, "Остановлено", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(stop);
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
        }
    }

    private void startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши «Поверх других окон» для приложения и вернись назад", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
            return;
        }
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startFlow();
            } else {
                Toast.makeText(this, "Без этого разрешения стрелку не показать", Toast.LENGTH_LONG).show();
            }
        } else if (req == REQ_PROJECTION) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, OverlayService.class);
                i.putExtra("code", res);
                i.putExtra("data", data);
                startForegroundService(i);
                Toast.makeText(this, "Запущено. Открой Chess.com", Toast.LENGTH_LONG).show();
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "Запись экрана не разрешена", Toast.LENGTH_LONG).show();
            }
        }
    }
}
